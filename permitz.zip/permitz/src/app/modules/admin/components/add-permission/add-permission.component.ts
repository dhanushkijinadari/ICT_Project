import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-permission',
  templateUrl: './add-permission.component.html',
  styleUrls: ['./add-permission.component.css']
})
export class AddPermissionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
