import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-delete',
  templateUrl: './update-delete.component.html',
  styleUrls: ['./update-delete.component.css']
})
export class UpdateDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
