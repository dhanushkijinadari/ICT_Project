import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { AddPermissionComponent } from './components/add-permission/add-permission.component';
import { UpdateDeleteComponent } from './components/update-delete/update-delete.component';
import { LogoutComponent } from './components/logout/logout.component';
import { AccountComponent } from './components/account/account.component';
import { AdminHomeComponent } from './components/admin-home/admin-home.component';
import { UpdateDeleteSearchConfirmComponent } from './components/update-delete-search-confirm/update-delete-search-confirm.component';


@NgModule({
  declarations: [
    AdminDashboardComponent,
    HeaderComponent,
    FooterComponent,
    AddPermissionComponent,
    UpdateDeleteComponent,
    LogoutComponent,
    AccountComponent,
    AdminHomeComponent,
    UpdateDeleteSearchConfirmComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule
  ]
})
export class AdminModule { }
