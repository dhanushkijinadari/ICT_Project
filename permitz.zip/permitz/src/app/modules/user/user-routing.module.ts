import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckPermissionComponent } from './components/check-permission/check-permission.component';
import { UserAccountComponent } from './components/user-account/user-account.component';
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component';
import { UserHomeComponent } from './components/user-home/user-home.component';

const routes: Routes = [
  {path:'', component:UserDashboardComponent,
    children:[
    {path:'user-home', component:UserHomeComponent},
    {path: 'check-permission',component:CheckPermissionComponent},
    {path: 'user-account', component:UserAccountComponent},
    {path : '', redirectTo:'/user/user-home', pathMatch: 'full'},
    ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
