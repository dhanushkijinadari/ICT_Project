import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { isConstructorDeclaration } from 'typescript';
import { Observable } from 'rxjs';
import {AdminSignupComponent} from '../components/admin-signup/admin-signup.component'

@Injectable({
  providedIn: 'root'
})
export class AdminService {


  url ='http://localhost:3000/adminsignup'
  constructor(private http:HttpClient) { }

  adminsignup() {
    return this.http.get(this.url);
  }

  user(data:any) {
    return this.http.post(this.url, data);

  }
}
