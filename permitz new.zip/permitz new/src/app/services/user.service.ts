import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { isConstructorDeclaration } from 'typescript';
import { Observable } from 'rxjs';
import { UserSignupComponent } from '../components/user-signup/user-signup.component'

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url = 'http://localhost:3000/usersignup'

  constructor(private http: HttpClient) { }

  usersignup() {
    return this.http.get(this.url);
  }

  user(data:any) {
    return this.http.post(this.url, data);

  }
}
