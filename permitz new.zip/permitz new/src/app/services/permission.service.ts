import { Injectable } from '@angular/core';
import{ HttpClient } from '@angular/common/http'
//import {admin} from '../modules/admin.module'
import { isConstructorDeclaration } from 'typescript';
import { Observable } from 'rxjs';
import { AddPermissionComponent } from '../modules/admin/components/add-permission/add-permission.component';

@Injectable({
  providedIn: 'root'
})
export class PermissionService {
  url =' http://localhost:3000/vehicleaddpermission'

  constructor(private http:HttpClient) { }
    vehicleaddpermission(){
      return this.http.get(this.url);
    }

    savepermission(){
      return this.http.post(this.url,data);
    }
  
 

  
}



function data(url: string, data: any) {
  throw new Error('Function not implemented.');
}

