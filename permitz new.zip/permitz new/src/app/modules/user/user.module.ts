import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { UserHomeComponent } from './components/user-home/user-home.component';
import { CheckPermissionComponent } from './components/check-permission/check-permission.component';
import { UserAccountComponent } from './components/user-account/user-account.component';
import {MatInputModule} from '@angular/material/input';
import {MatCardModule} from '@angular/material/card';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    UserDashboardComponent,
    HeaderComponent,
    FooterComponent,
    UserHomeComponent,
    CheckPermissionComponent,
    UserAccountComponent
  ],
  imports: [
    CommonModule,
    UserRoutingModule,
    MatInputModule,
    MatCardModule,
    FormsModule, 
    ReactiveFormsModule
  ]
})
export class UserModule {
  
 }
