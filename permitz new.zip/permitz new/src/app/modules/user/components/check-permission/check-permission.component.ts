import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validator, Validators } from '@angular/forms';


@Component({
  selector: 'app-check-permission',
  templateUrl: './check-permission.component.html',
  styleUrls: ['./check-permission.component.css']
})
export class CheckPermissionComponent implements OnInit {

  checkpermission = new FormGroup({
    vehicleNo : new FormControl('',[Validators.required])
  })
  constructor() { }

  ngOnInit(): void {
  }
  check(): void {
    console.log(this.checkpermission.value);
  }

}
