import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validator, Validators } from '@angular/forms';
import { PermissionService } from '../../../../services/permission.service'
@Component({
  selector: 'app-add-permission',
  templateUrl: './add-permission.component.html',
  styleUrls: ['./add-permission.component.css']
})
export class AddPermissionComponent implements OnInit {

  alert: boolean=false
  addpermission = new FormGroup({
    vehicleNo: new FormControl('', [Validators.required]),
    company: new FormControl('', [Validators.required]),
    driverName: new FormControl('', [Validators.required]),
    route: new FormControl('', [Validators.required]),
    travelpur: new FormControl('', [Validators.required]),
  });
  constructor(private permission: PermissionService) { }

  ngOnInit(): void {
  }

  Save(){
    //console.log(this.addpermission.value);
    //this.addpermission.vehicleaddpermission(this.addpermission.value);
    this.permission.vehicleaddpermission().subscribe(
      (res) => {console.log(res) }
    )

    this.alert=true
    this.addpermission.reset({})

  }

  closeAlert(){
    this.alert=false
  }





}
