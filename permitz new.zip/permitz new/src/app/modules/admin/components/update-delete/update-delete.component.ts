import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validator, Validators } from '@angular/forms';

@Component({
  selector: 'app-update-delete',
  templateUrl: './update-delete.component.html',
  styleUrls: ['./update-delete.component.css']
})
export class UpdateDeleteComponent implements OnInit {

  editpermission = new FormGroup({
    vehicleNo : new FormControl('',[Validators.required])
  })
  constructor() { }

  ngOnInit(): void {
  }

  search(): void{
    console.log(this.editpermission.value);
  }

}
