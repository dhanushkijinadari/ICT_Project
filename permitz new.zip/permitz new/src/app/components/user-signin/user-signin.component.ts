import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validator, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthGuard } from 'src/app/guards/auth.guard';
import { AuthService } from 'src/app/services/auth.service';


@Component({
  selector: 'app-user-signin',
  templateUrl: './user-signin.component.html',
  styleUrls: ['./user-signin.component.css']
})
export class UserSigninComponent implements OnInit {

  signinForm = new FormGroup({
    username : new FormControl('',[Validators.required]),
    password : new FormControl('',[Validators.required]),
  });
  constructor(private auth:AuthService,private router: Router) { }

  ngOnInit(): void {
    if (this.auth.isLoggedIn()) {
      this.router.navigate(['user']);
    }
  }
  
  onSubmit(): void {
      if (this.signinForm.valid) {
        this.auth.login(this.signinForm.value).subscribe(
          (result) => {
            console.log(result);
            this.router.navigate(['/user']);
          },
          (err: Error) => {
            alert(err.message);
          }
        );
      }
  }
  
  }


