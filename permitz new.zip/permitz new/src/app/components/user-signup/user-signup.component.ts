import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from "@angular/router";
//import { MatSnackBar } from '@angular/material';
import {UserService} from '../../services/user.service'

@Component({
  selector: 'app-user-signup',
  templateUrl: './user-signup.component.html',
  styleUrls: ['./user-signup.component.css']
})
export class UserSignupComponent implements OnInit {

  usersignup = new FormGroup({
    firstname : new FormControl('',[Validators.required , Validators.pattern('[a-zA-Z]')]),
    lastname : new FormControl('',[Validators.required , Validators.pattern('[a-zA-Z]')]),
    policeid : new FormControl('',[Validators.required]),
    phoneNo : new FormControl('',[Validators.required,Validators.pattern('[0-9]'), Validators.minLength(10)]),
    password : new FormControl('',[Validators.required, Validators.minLength(8)]),
    confirmpassword : new FormControl('',[Validators.required]),
  });

  constructor(private user:UserService){

  }

  ngOnInit(): void {

    }
  
  signup(){
    console.log(this.usersignup.value);
    this.user.usersignup().subscribe(
      (res) => {console.log(res) }
    )
  }


  /*signup(formdata) {
    this.authService.register(formdata).subscribe(
      (res) => {
        window.sessionStorage.setItem('isLogged','true');
        console.log("Success" + res);
        this.snackbar.open("Successfully registerd","ok",{duration:2000})
        // this.toastr.success('Addign an admin', 'Addes successfully');
        this.router.navigate(["/dashboard"]);
      },
      (err) => {
        this.snackbar.open("oops !! something is not right","ok",{duration:2000})
        console.log("Failed" + err);
      }
    );
  }*/

}
