import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder, FormControl } from '@angular/forms';
import {MatDialog} from '@angular/material/dialog';
import { TermOfUseComponent } from '../term-of-use/term-of-use.component';
import {AdminService} from '../../services/admin.service'

@Component({
  selector: 'app-admin-signup',
  templateUrl: './admin-signup.component.html',
  styleUrls: ['./admin-signup.component.css']
})
export class AdminSignupComponent implements OnInit {

  adminsignup = new FormGroup({
    firstname : new FormControl('',[Validators.required , Validators.pattern('[a-zA-Z]')]),
    lastname : new FormControl('',[Validators.required , Validators.pattern('[a-zA-Z]')]),
    policeid : new FormControl('',[Validators.required]),
    phoneNo : new FormControl('',[Validators.required,Validators.pattern('[0-9]'), Validators.minLength(10)]),
    password : new FormControl('',[Validators.required, Validators.minLength(8)]),
    confirmpassword : new FormControl('',[Validators.required]),
  });

  constructor(public dialog: MatDialog,private admin:AdminService ) {}

  openDialog() {
    const dialogRef = this.dialog.open(TermOfUseComponent);
   dialogRef.afterClosed().subscribe(result => {
    console.log(`Dialog result: ${result}`);
  });
    
  }

  ngOnInit(): void {
  }

  signup(){
    console.log(this.adminsignup.value);
    this.admin.adminsignup().subscribe(
      (res) => {console.log(res) }
    )
  }

}




