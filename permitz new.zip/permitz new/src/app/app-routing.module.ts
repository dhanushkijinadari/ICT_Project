import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminSigninComponent } from './components/admin-signin/admin-signin.component';
import { AdminSignupComponent } from './components/admin-signup/admin-signup.component';
import { HomeComponent } from './components/home/home.component';
import { TermOfUseComponent } from './components/term-of-use/term-of-use.component';
import { UserSigninComponent } from './components/user-signin/user-signin.component';
import { UserSignupComponent } from './components/user-signup/user-signup.component';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  {path:'adminsignin',component: AdminSigninComponent},
  {path:'adminsignup',component: AdminSignupComponent},
  {path:'usersignup',component: UserSignupComponent},
  {path:'usersignin',component: UserSigninComponent},
  {path:'home',component: HomeComponent},
  {path: 'termofuse',component: TermOfUseComponent},
  {path : 'admin',
  loadChildren: ()=> import('./modules/admin/admin.module').then((m) =>m.AdminModule),},
  {path : 'user',
  canActivate : [AuthGuard],
  loadChildren: ()=> import('./modules/user/user.module').then((m) =>m.UserModule),},
  {path:'',redirectTo:'/home',pathMatch:'full'}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
