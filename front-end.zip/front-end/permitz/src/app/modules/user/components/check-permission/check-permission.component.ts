import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-permission',
  templateUrl: './check-permission.component.html',
  styleUrls: ['./check-permission.component.css']
})
export class CheckPermissionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
