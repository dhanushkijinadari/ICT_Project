import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-delete-search-confirm',
  templateUrl: './update-delete-search-confirm.component.html',
  styleUrls: ['./update-delete-search-confirm.component.css']
})
export class UpdateDeleteSearchConfirmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
