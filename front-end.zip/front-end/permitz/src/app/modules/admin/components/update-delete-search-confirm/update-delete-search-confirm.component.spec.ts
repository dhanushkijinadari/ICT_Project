import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateDeleteSearchConfirmComponent } from './update-delete-search-confirm.component';

describe('UpdateDeleteSearchConfirmComponent', () => {
  let component: UpdateDeleteSearchConfirmComponent;
  let fixture: ComponentFixture<UpdateDeleteSearchConfirmComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateDeleteSearchConfirmComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateDeleteSearchConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
