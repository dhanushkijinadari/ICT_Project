import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountComponent } from './components/account/account.component';
import { AddPermissionComponent } from './components/add-permission/add-permission.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { AdminHomeComponent } from './components/admin-home/admin-home.component';
import { LogoutComponent } from './components/logout/logout.component';
import { UpdateDeleteSearchConfirmComponent } from './components/update-delete-search-confirm/update-delete-search-confirm.component';
import { UpdateDeleteComponent } from './components/update-delete/update-delete.component';

const routes: Routes = [
  {path: '', component : AdminDashboardComponent, 
  children:[
    {path : 'admin-home', component:AdminHomeComponent},
    {path : 'add-permission', component:AddPermissionComponent},
    {path : 'update-delete', component:UpdateDeleteComponent},
    {path : 'update-delete-search-confirm', component:UpdateDeleteSearchConfirmComponent},
    {path : 'logout', component:LogoutComponent},
    {path : 'account', component:AccountComponent},

    {path : '', redirectTo:'/admin/admin-home', pathMatch: 'full'},

  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
